##Vic1


iconv.recursive <- function (x, from) { # Creamos la función auxiliar "iconv.recursive" para convertir todas las cadenas a la codificación actual.
	attribs <- attributes (x);
	if (is.character (x)) {
		x <- iconv (x, from=from, to="", sub="")
	} else if (is.list (x)) {
		x <- lapply (x, function (sub) iconv.recursive (sub, from))
	} # Convierte niveles de factor y todos los demás atributos.
	attributes (x) <- lapply (attribs, function (sub) iconv.recursive (sub, from)) #Crea los atributos para todos los elementos de la lista.
	x
} # La función "iconv.recursive" fue elaborada por los contribuidores de RKWard, y se encuentra disponible en su menú de importación genérica "Archivo->Importar->Formato de Importación->Importación genérica (basada en rio)"

##Importar el archivo de categorías de datos

local({
## Computar
setwd("/home/cano/Escritorio/ENOE/ENVIPE/conjunto_de_datos_TPer_Vic1_ENVIPE_2022/catalogos")
})

local({
## Preparar
require(rio)
# La función "iconv.recursive" fue elaborada por los contribuidores de RKWard, y se encuentra disponible en su menú de importación genérica "Archivo->Importar->Formato de Importación->Importación genérica (basada en rio)"
# El siguiente es un loop para importar todos los elementos del directorio a una lista.
arch_enlist <- list.files(pattern = "\\.csv$") # Enlista los archivos en directorio con extensión csv.
.GlobalEnv$meta.vic1 <- list()
.GlobalEnv$meta.vic1$cat <- list()   # Creamos la lista en el Ambiente Global (".GlobalEnv") para guardar el resultado del loop subsecuente.
for (i in arch_enlist) {         # Iniciamos el loop para importar todos los archivos del directorio.
data <- import(i)               # Importa los archivos en el directorio.
data <- iconv.recursive (data, from= "latin1") # Convertir todas las cadenas de "latin1" a la codificación actual.
.GlobalEnv$meta.vic1$cat[[i]] <- data #Asigna el resultado del loop a a lista cat en el Ambiente Global.
}
})

#se detectó que zona.csv no está en latin1 encoding, para ello usamos "uchardet" para detectar automáticamente la codificación.
#library(uchardet)
#meta.vic1$cat$zona.csv <- read.csv('zona.csv', encoding=detect_file_enc("zona.csv")) 


# Para limpiar los nombres usamos stringr.

library(stringr)
names(meta.vic1$cat) <- str_replace(names(meta.vic1$cat), pattern = ".csv", replacement = "")
# Para eliminar la cadena ."csv", de los nombres.
# Luego, convertimos a mayúsculas si lo necesitamos (es el caso de los archivos DBF, para los csv se encuentran en minúsculas)
# names(cat) <- str_to_upper(names(cat))



##Data frame para seleccionar variables con el diccionario de datos

#Diccionario de datos para importar etiquetas de variable y de valor
#Seleccionamos el directorio del dicionario de datos (diccionario_de_datos)
local({
## Computar
setwd("/home/cano/Escritorio/ENOE/ENVIPE/conjunto_de_datos_TPer_Vic1_ENVIPE_2022/diccionario_de_datos")
})


##Importar diccionario de datos
local({
## Preparar
require(rio)
# helper function to convert all strings to the current encoding
## Computar
data <- import("diccionario_de_datos_TPer_Vic1_ENVIPE_2022.csv")
# convert all strings to the current encoding
data <- iconv.recursive (data, from="latin1")
library(janitor)
data <- clean_names (data)
.GlobalEnv$meta.vic1$dic <- data  # asignar a globalenv()
#rk.edit(.GlobalEnv$dic)
## Imprimir el resultado
#rk.header ("Importar datos genéricos", parameters=list("Nombre de archivo"="/home/cano/Escritorio/ENOE/3t2022/conjunto_de_datos_coe1_enoen_2022_3t/diccionario_de_datos/diccionario_datos_coe1_enoen_2022_3t.csv",
#	"Objeto en el que guardar"="dic"))
})


#Creamos un marco de datos para seleccionar las variables cuyos valores deberán ser etiquetados.
meta.vic1$nombres <- data.frame(cbind("catalogo"=meta.vic1$dic[["nemonico"]], "nombre_campo"=meta.vic1$dic[["nombre_campo"]])) #Crear un nuevo data.frame
#meta.vic1$nombres[["catalogo"]] <- replace(meta.vic1$nombres[["catalogo"]], meta.vic1$nombres[["catalogo"]]=='', NA) #cambiar celdas en blanco por NA.
#library(tidyr)
#meta.vic1$nombres <- drop_na(meta.vic1$nombres) 
meta.vic1$nombres <-meta.vic1$nombres[!duplicated(meta.vic1$nombres$catalogo), ]


 # elimina rangos de variables que no llevan etiquetas. El 22 es la clave de carrera cuyo catálogo CSV no tiene nombres
library(tibble)
meta.vic1$nombres  <- rownames_to_column(meta.vic1$nombres ,var="id")

##Importar el Archivo con los datos

local({
## Computar
setwd("/home/cano/Escritorio/ENOE/ENVIPE/conjunto_de_datos_TPer_Vic1_ENVIPE_2022/conjunto_de_datos")
})


local({
## Preparar
require(rio)
# helper function to convert all strings to the current encoding
iconv.recursive <- function (x, from) {
	attribs <- attributes (x);
	if (is.character (x)) {
		x <- iconv (x, from=from, to="", sub="")
	} else if (is.list (x)) {
		x <- lapply (x, function (sub) iconv.recursive (sub, from))
	}
	# convert factor levels and all other attributes
	attributes (x) <- lapply (attribs, function (sub) iconv.recursive (sub, from))
	x
}
## Computar
data <- import("conjunto_de_datos_TPer_Vic1_ENVIPE_2022.csv")

# convert all strings to the current encoding latin1
data <- iconv.recursive (data, from="latin1")
#data <- iconv.recursive (data, from="UTF-8")
.GlobalEnv$meta.vic1$data <- data# asignar a globalenv()
#rk.edit(.GlobalEnv$data)
## Imprimir el resultado
#rk.header ("Importar datos genéricos", parameters=list("Nombre de archivo"="/home/cano/Escritorio/ENOE/ENVIPE/conjunto_de_datos_TSDem_ENVIPE_2022/conjunto_de_datos/conjunto_de_datos_TSDem_ENVIPE_2022.csv",
#	"Objeto en el que guardar"="data"))
})


meta.vic1$factrs <- meta.vic1$nombres

meta.vic1$factrs <- meta.vic1$factrs[-(c(1:8,12,14,111,174:177,180,181)),] # elimina rangos de variables que no llevan etiquetas. El 22 es la clave de carrera cuyo catálogo CSV no tiene nombres
#EDAD

local({
list_names <- meta.vic1$factrs[["catalogo"]] #enlista las variables deseadas
for (e in list_names)  {
f <- meta.vic1$data
f[[e]]<- as.factor(f[[e]]) #es el mismo resultado que con forcats::as_factor pues las variables son numéricas
.GlobalEnv$meta.vic1$data <-f
}
})


##apply
#meta.vic1[["data"]][["EDAD"]] <- as.numeric(meta.vic1[["data"]][["EDAD"]])

meta.vic1[["data"]][,c(10,174:177)] <- sapply(meta.vic1[["data"]][,c(10,174:177)], as.numeric)


meta.vic1$factrs.r <- meta.vic1$factrs[-(c(4:5)),] 

local({
library(lookup)
df <- meta.vic1$data
for (i in meta.vic1[["nombres"]][["catalogo"]]) 
{
rk.set.label(df[[i]],
vlookup(i, 
meta.vic1[["nombres"]],
"catalogo",
"nombre_campo")
)
}
.GlobalEnv$meta.vic1$data <- df
})




local({
l <- meta.vic1[["cat"]]
list_names <- names(l)
for (i in list_names){
f <- meta.vic1[["cat"]][[i]]
f$CVE <- f[[i]]
l[[i]] <- f}
.GlobalEnv$ meta.vic1[["cat"]] <- l
})


# Asignar etiqueta de nivel a cada valor,
##Recode
local({
library(lookup)
list_names <- meta.vic1$factrs.r[["catalogo"]] 
d <- meta.vic1$data
for (i in list_names){
f <- meta.vic1$cat[[i]]
v <- d[[i]]
levels(v) <- vlookup(levels(v),
f,
"CVE",
"descrip")
d[[i]] <- v
}
.GlobalEnv$meta.vic1$data <- d
})
